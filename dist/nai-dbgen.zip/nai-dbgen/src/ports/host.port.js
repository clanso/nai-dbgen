/**
 * L2 契约 · HostPort —— 插件对 SillyTavern 的全部依赖面（架构文档 §4.1）。
 * 无具体实现；仅 JSDoc typedef + 运行时自检。不得 import 酒馆或 adapters。
 * 归属：W0 冻结；实现归 W1-B `adapters/host/sillytavern.host.js`。
 */

import { Ok, Err } from '../infra/result.js';
import { hostError } from '../infra/errors.js';
import { requireArg } from '../infra/validate.js';

/**
 * @typedef {string} ChatId
 */

/**
 * @typedef {object} HostMessage
 * @property {number} messageId 楼层下标（= chat 数组下标）
 * @property {string} name 发言人名
 * @property {string} text 楼层正文（含 slot 原文）
 * @property {boolean} isUser
 * @property {boolean} isSystem
 * @property {object} [extra] message.extra
 */

/**
 * @typedef {() => void} Unsubscribe
 */

/**
 * 酒馆宿主端口。业务语言，不暴露 ST 事件名 / MutationObserver。
 * 失败分类：宿主能力缺失 → HostError；用户配置导致 → ConfigError。
 *
 * 对应宿主能力基线：§1 扩展装载、§2–3 渲染管线、§4 正则、§5 interceptor、
 * §6 世界书、§9 存储、§11 UI API。
 *
 * @typedef {object} HostPort
 *
 * @property {() => (ChatId|null)} getCurrentChatId
 *   当前聊天文件名 id（酒馆 getCurrentChatId）；无打开聊天时 null。闸门键用。
 *
 * @property {() => (string|null)} getSessionId
 *   会话稳定 id = chat_metadata.integrity（改名不变；分支为新会话）。
 *   缺失时适配器生成并经 saveMetadata 落盘；仍无法取得则 null。
 *
 * @property {() => ({ chatFileName: string|null, avatarUrl: string|null, groupId: string|null })} getChatLocation
 *   当前聊天在酒馆侧的定位信息，供目录文件登记 / 清理核对。
 *
 * @property {() => HostMessage[]} getMessages
 *   全部楼层，下标即 messageId。
 *
 * @property {(n: number) => HostMessage[]} getRecentAiMessages
 *   最近 n 条 AI 回复楼，新→旧；不含用户楼/系统楼（需求 4.6）。
 *
 * @property {(messageId: number) => (HostMessage|null)} getMessage
 *
 * @property {(messageId: number) => string[]} getMessageSwipeTexts
 *   某楼全部 swipe 正文（含当前 mes）；无 swipe 时返回 [当前正文]。
 *
 * @property {(messageId: number, newText: string) => Promise<import('../infra/result.js').Ok<void>|import('../infra/result.js').Err<import('../infra/errors.js').AppError>>} replaceMessageText
 *   唯一允许改正文的入口。失败：HostError。
 *
 * @property {(messageId: number) => void} rerenderMessage
 *   重绘某楼 DOM。
 *
 * @property {() => Promise<import('../infra/result.js').Ok<void>|import('../infra/result.js').Err<import('../infra/errors.js').AppError>>} ensureSlotRegexInstalled
 *   写入/校验/补装两条正则。失败：HostError(REGEX_MISSING) / ConfigError。基线 §4。
 *
 * @property {(fn: (messageEl: Element, messageId: number) => void) => Unsubscribe} onMessageDomReady
 *   某楼 DOM 出现/重建时回调（幂等）。基线 §3。
 *
 * @property {(fn: (mes: string, msgMeta: object) => string) => Unsubscribe} registerOutboundTransform
 *   出站提示词变换（剥 slot 兜底）。基线 §5。
 *
 * @property {(args: { contextWindow: HostMessage[], messageId?: number }) => Promise<import('../infra/result.js').Ok<string>|import('../infra/result.js').Err<import('../infra/errors.js').AppError>>} resolveWorldInfo
 *   用调用方给定的上下文窗口跑 getWorldInfoPrompt，副作用已隔离（裁决 D6 / 架构 §6.3）。
 *   必须收 contextWindow 而不是楼号：世界书与角色、标签由同一窗口派生。
 *   messageId 仅用于日志与 trace。「是否带发言人名」由适配器读酒馆
 *   world_info_include_names 决定，不上浮到 application。失败可降级为空串（HostError）。基线 §6。
 *
 * @property {(fn: (chatId: ChatId|null) => void) => Unsubscribe} onChatChanged
 *
 * @property {(fn: (chatFileName: string) => void) => Unsubscribe} onChatDeleted
 *   单聊被删（CHAT_DELETED，载荷为无 .jsonl 的文件名）。
 *
 * @property {(fn: (groupChatId: string) => void) => Unsubscribe} onGroupChatDeleted
 *   群聊被删（GROUP_CHAT_DELETED）。
 *
 * @property {(fn: (info: { avatarId?: string|null, groupId?: string|null, oldFileName: string, newFileName: string }) => void) => Unsubscribe} onChatRenamed
 *   聊天改名（CHAT_RENAMED）。
 *
 * @property {() => Promise<import('../infra/result.js').Ok<Array<{ chatFileName: string, avatarUrl: string|null, groupId: string|null, integrity: string|null }>>|import('../infra/result.js').Err<import('../infra/errors.js').AppError>>} listAliveChats
 *   列出当前用户下仍存在的角色/群组聊天（含 integrity，供存储清理核对）。
 *
 * @property {(fn: (messageId: number) => void) => Unsubscribe} onAiMessageSettled
 *   流式结束后才触发。基线 §3 CHARACTER_MESSAGE_RENDERED 语义封装。
 *
 * @property {() => import('../domain/model/plugin-settings.js').PluginSettings} loadSettings
 *   读 extension_settings['nai-dbgen']，形状见 PluginSettings（裁决 D8）。基线 §9。
 *
 * @property {(settings: import('../domain/model/plugin-settings.js').PluginSettings) => void} saveSettings
 *   debounced 写回小配置（完整 PluginSettings，非随意 patch 对象）。
 *
 * @property {(element: Element) => void} mountSettingsPanel
 *   挂到 #extensions_settings2。基线 §11。
 *
 * @property {(opts: { title: string, element: Element, wide?: boolean, large?: boolean, allowVerticalScrolling?: boolean, prepareDialog?: (dialog: HTMLDialogElement) => void }) => Promise<void>} openModal
 *   包一层酒馆 Popup（基线 §11）。必须透传 `wide` / `large` / `allowVerticalScrolling`（裁决 D20），
 *   不得写死一档——管理台要 large，小确认框不要。`prepareDialog` 在宿主首次显示前同步调用。
 *
 * @property {(spec: object) => void} registerSlashCommand
 *
 * @property {(level: 'info'|'success'|'warning'|'error', message: string) => void} toast
 *
 * @property {() => void} dispose
 *   干净卸载：取消事件订阅、停观察器、卸全局拦截器等（裁决 D18）。
 *   manifest `hooks.disable` → bootstrap dispose 必须能调用到本方法。可重复调用。
 */

/** @type {readonly string[]} */
const REQUIRED_METHODS = Object.freeze([
    'getCurrentChatId',
    'getSessionId',
    'getChatLocation',
    'getMessages',
    'getRecentAiMessages',
    'getMessage',
    'getMessageSwipeTexts',
    'replaceMessageText',
    'rerenderMessage',
    'ensureSlotRegexInstalled',
    'onMessageDomReady',
    'registerOutboundTransform',
    'resolveWorldInfo',
    'onChatChanged',
    'onChatDeleted',
    'onGroupChatDeleted',
    'onChatRenamed',
    'listAliveChats',
    'onAiMessageSettled',
    'loadSettings',
    'saveSettings',
    'mountSettingsPanel',
    'openModal',
    'registerSlashCommand',
    'toast',
    'dispose',
]);

/**
 * 运行时自检：必需方法存在且为 function。缺失 → HostError。
 * @param {unknown} impl
 * @returns {{ ok: true, value: HostPort } | { ok: false, error: import('../infra/errors.js').AppError }}
 */
export function assertHostPort(impl) {
    requireArg(impl != null, 'impl');
    /** @type {string[]} */
    const missing = [];
    for (const name of REQUIRED_METHODS) {
        if (typeof /** @type {Record<string, unknown>} */ (impl)[name] !== 'function') {
            missing.push(name);
        }
    }
    if (missing.length > 0) {
        return Err(hostError({
            code: 'HOST_PORT_INCOMPLETE',
            message: '宿主端口实现不完整',
            hint: '请更新插件或检查装配容器',
            context: { missing },
        }));
    }
    return Ok(/** @type {HostPort} */ (impl));
}

export { REQUIRED_METHODS as HOST_PORT_METHODS };
